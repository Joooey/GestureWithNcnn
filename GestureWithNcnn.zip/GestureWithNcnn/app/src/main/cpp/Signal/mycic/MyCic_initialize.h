//
// File: MyCic_initialize.h
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 24-Mar-2017 13:57:42
//
#ifndef __MYCIC_INITIALIZE_H__
#define __MYCIC_INITIALIZE_H__

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "MyCic_types.h"

// Function Declarations
extern void MyCic_initialize();

#endif

//
// File trailer for MyCic_initialize.h
//
// [EOF]
//
