//
// File: ADist_types.h
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 25-Jul-2017 17:12:03
//
#ifndef ADIST_TYPES_H
#define ADIST_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for ADist_types.h
//
// [EOF]
//
