package com.example.dmrf.gesturewithncnn.TestProcess;

import com.example.dmrf.gesturewithncnn.JniClass.SignalProcess;

public class SignalNativeTest {

    private SignalProcess signalProcess;


}
