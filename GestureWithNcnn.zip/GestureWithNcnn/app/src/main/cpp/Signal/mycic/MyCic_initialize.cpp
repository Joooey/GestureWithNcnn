//
// File: MyCic_initialize.cpp
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 24-Mar-2017 13:57:42
//

// Include Files
#include "rt_nonfinite.h"
#include "MyCic.h"
#include "MyCic_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void MyCic_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for MyCic_initialize.cpp
//
// [EOF]
//
