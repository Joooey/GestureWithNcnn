//
// File: step.h
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 24-Mar-2017 13:57:42
//
#ifndef __STEP_H__
#define __STEP_H__

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "MyCic_types.h"

// Function Declarations
extern void Destructor(dsp_private_Integrator_0 *obj);
extern void InitializeConditions(dsp_private_Integrator_0 *obj);
extern void b_Destructor(dsp_private_Integrator_1 *obj);
extern void b_InitializeConditions(dsp_private_Integrator_1 *obj);
extern void c_Destructor(dsp_private_Integrator_2 *obj);
extern void c_InitializeConditions(dsp_private_Integrator_2 *obj);
extern void d_Destructor(dsp_Delay_3 *obj);
extern void d_InitializeConditions(dsp_Delay_3 *obj);
extern void e_Destructor(dsp_Delay_4 *obj);
extern void e_InitializeConditions(dsp_Delay_4 *obj);
extern void f_Destructor(dsp_Delay_5 *obj);
extern void f_InitializeConditions(dsp_Delay_5 *obj);

#endif

//
// File trailer for step.h
//
// [EOF]
//
