//
// File: CICDecimator.h
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 24-Mar-2017 13:57:42
//
#ifndef __CICDECIMATOR_H__
#define __CICDECIMATOR_H__

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "MyCic_types.h"

// Function Declarations
extern void CICDecimator_stepImpl(dsp_CICDecimator_2 *obj, const int in[6600],
  long long out[165]);

#endif

//
// File trailer for CICDecimator.h
//
// [EOF]
//
